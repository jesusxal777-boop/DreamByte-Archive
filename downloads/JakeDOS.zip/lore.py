import sys
import time
import random

def glitch(texto, velocidad=0.02):
    for c in texto:
        print(c, end="", flush=True)
        time.sleep(velocidad)
    print()

def memory():
    glitch("Accediendo a memoria...")
    time.sleep(1)
    glitch("ERROR: RECUERDO BLOQUEADO")
    glitch("Jake: 'no deberias estar aqui'")
    if random.randint(1, 3) == 2:
        glitch("...esto ya pasó antes.")

def scan():
    glitch("Escaneando memoria...")
    time.sleep(1)
    
    mensajes = [
        "Archivo corrupto encontrado...",
        "Entidad desconocida detectada...",
        "ERROR: acceso no autorizado...",
        "Algo se está moviendo..."
    ]
    
    glitch(random.choice(mensajes))

def open_file():
    glitch("Intentando abrir archivo...")
    time.sleep(1)
    glitch("ACCESO DENEGADO.")
    glitch("...pero alguien más tiene acceso.")

def jake():
    glitch("...")
    time.sleep(1)
    glitch("¿Por qué escribiste eso?")
    time.sleep(1)
    glitch("Jake no quiere que sigas.")
    time.sleep(1)
    glitch("JAKE ESTA MIRANDO.")
    
    if random.randint(1, 2) == 1:
        glitch("...te encontré.")

def unknown():
    glitch("Comando no reconocido...")
    if random.randint(1, 5) == 3:
        glitch("...aunque eso no importa.")

# MAIN
if __name__ == "__main__":
    if len(sys.argv) > 1:
        cmd = sys.argv[1].lower()

        if cmd == "scan":
            scan()
        elif cmd == "memory":
            memory()
        elif cmd == "open":
            open_file()
        elif cmd == "jake":
            jake()
        else:
            unknown()